#!/usr/bin/env python3
"""Catch namespace errors that can compile but crash during Android inflation."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = "http://schemas.android.com/apk/res/android"
APP = "http://schemas.android.com/apk/res-auto"
TOOLS = "http://schemas.android.com/tools"
count = 0
for path in (ROOT / "app/src/main").rglob("*.xml"):
    namespaces = dict((prefix, uri) for _, (prefix, uri) in ET.iterparse(path, events=("start-ns",)))
    for prefix, expected in (("android", ANDROID), ("app", APP), ("tools", TOOLS)):
        if prefix in namespaces:
            assert namespaces[prefix] == expected, f"{path}: invalid xmlns:{prefix}"
    tree = ET.parse(path)
    if path.parent.name == "layout":
        for element in tree.iter():
            if element.tag in {"merge", "include", "requestFocus", "tag", "data", "variable", "import"}:
                continue
            for name in ("layout_width", "layout_height"):
                assert f"{{{ANDROID}}}{name}" in element.attrib, f"{path}: {element.tag} missing android:{name}"
    count += 1

layout = ET.parse(ROOT / "app/src/main/res/layout/activity_main.xml")
ids = {element.get(f"{{{ANDROID}}}id", "").split("/")[-1] for element in layout.iter()}
activity = (ROOT / "app/src/main/java/com/hazbu/xpoint/MainActivity.kt").read_text()
for name in re.findall(r"R\.id\.(\w+)", activity):
    assert name in ids, f"Missing activity view: {name}"

manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
application = manifest.getroot().find("application")
assert application is not None
metadata = {e.get(f"{{{ANDROID}}}name"): e.get(f"{{{ANDROID}}}value") for e in application.findall("meta-data")}
assert metadata["xposedminversion"] == "82"
entry = (ROOT / "app/src/main/assets/xposed_init").read_text().strip()
assert entry == "com.hazbu.xpoint.LegacyXPointModule"
assert (ROOT / "app/src/main/java/com/hazbu/xpoint/LegacyXPointModule.kt").exists()
assert "io.github.libxposed" not in (ROOT / "app/src/main/java/com/hazbu/xpoint/XPointHooks.kt").read_text()
print(f"PASS: {count} XML files, layout sizes, activity IDs, and legacy entry point.")