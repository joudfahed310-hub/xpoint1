package com.hazbu.xpoint

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import com.hazbu.xpoint.Constants.AUTHORITY
import com.hazbu.xpoint.Constants.DEFAULT_LAT
import com.hazbu.xpoint.Constants.DEFAULT_LONG
import com.hazbu.xpoint.Constants.KEY_IS_ENABLED
import com.hazbu.xpoint.Constants.KEY_LAT
import com.hazbu.xpoint.Constants.KEY_LONG
import com.hazbu.xpoint.Constants.PREFS_NAME
import java.util.Locale
import kotlin.math.cos

class JoystickService : Service() {

    companion object {
        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: GridLayout
    private var stepMeters: Double = 1.0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val requestedStep = intent?.getDoubleExtra("STEP_METERS", 1.0) ?: 1.0
        stepMeters = if (requestedStep.isFinite()) requestedStep.coerceAtLeast(1.0) else 1.0
        return if (isRunning) START_STICKY else START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        try {
            startForegroundServiceNotification()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "اسمح لـ xPoint بالظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
                stopSelf()
                return
            }
            setupFloatingJoystick()
            isRunning = true
        } catch (error: RuntimeException) {
            Log.e("xPoint", "Unable to start floating joystick", error)
            Toast.makeText(this, "تعذر تشغيل الزر العائم؛ تحقق من إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun startForegroundServiceNotification() {
        val channelId = "xpoint_joystick_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "xPoint Joystick", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("xPoint Pro")
            .setContentText("الزر العائم نشط الآن")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
        startForeground(1001, notification)
    }

    private fun setupFloatingJoystick() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#F2222630"))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#667C83FF"))
        }

        floatingView = GridLayout(this).apply {
            rowCount = 1
            columnCount = 1
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val controls = GridLayout(this).apply {
            rowCount = 3
            columnCount = 3
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = bg
            setPadding(dp(6), dp(6), dp(6), dp(6))
            visibility = View.GONE
            elevation = dp(6).toFloat()
        }
        val bubble = createDirButton("✥") {}.apply {
            contentDescription = "فتح لوحة الحركة؛ اسحب لنقل الزر"
            textSize = 26f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#F24F46E5"))
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(6).toFloat()
            layoutParams = GridLayout.LayoutParams(
                GridLayout.spec(0), GridLayout.spec(0)
            ).apply { width = dp(52); height = dp(52) }
        }

        fun showPanel(expanded: Boolean) {
            bubble.visibility = if (expanded) View.GONE else View.VISIBLE
            controls.visibility = if (expanded) View.VISIBLE else View.GONE
            floatingView.requestLayout()
        }
        bubble.setOnClickListener { showPanel(true) }
        val btnCollapse = createDirButton("−") { showPanel(false) }.apply {
            contentDescription = "طي اللوحة مع إبقاء الزر فعالًا"
        }
        val btnUp = createDirButton("↑") { moveLocation(stepMeters, 0.0) }.apply { contentDescription = "شمال" }
        val btnDown = createDirButton("↓") { moveLocation(-stepMeters, 0.0) }.apply { contentDescription = "جنوب" }
        val btnLeft = createDirButton("←") { moveLocation(0.0, -stepMeters) }.apply { contentDescription = "غرب" }
        val btnRight = createDirButton("→") { moveLocation(0.0, stepMeters) }.apply { contentDescription = "شرق" }
        val btnClose = createDirButton("×") { stopSelf() }.apply {
            contentDescription = "إيقاف الزر العائم؛ لا يوقف تزييف الموقع"
            setTextColor(Color.parseColor("#FF8A8A"))
        }

        val dragHandle = TextView(this).apply {
            text = "✥"
            contentDescription = "اسحب لنقل لوحة الحركة"
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.CENTER
            layoutParams = GridLayout.LayoutParams().apply { width = dp(48); height = dp(48) }
        }

        controls.addView(btnCollapse)
        controls.addView(btnUp)
        controls.addView(btnClose)
        controls.addView(btnLeft)
        controls.addView(dragHandle)
        controls.addView(btnRight)
        controls.addView(createEmptySpace())
        controls.addView(btnDown)
        controls.addView(createEmptySpace())
        floatingView.addView(bubble)
        floatingView.addView(controls, GridLayout.LayoutParams(
            GridLayout.spec(0), GridLayout.spec(0)
        ))

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = dp(16)
            y = dp(160)
        }

        fun attachDrag(view: View) {
            view.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var moved = false
            private val slop = ViewConfiguration.get(this@JoystickService).scaledTouchSlop

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop) moved = true
                        if (moved) {
                            params.x = initialX + dx.toInt()
                            params.y = initialY + dy.toInt()
                            clampPosition(params)
                            windowManager.updateViewLayout(floatingView, params)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v?.performClick()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
            })
        }
        attachDrag(bubble)
        attachDrag(dragHandle)
        floatingView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (floatingView.isAttachedToWindow) {
                val oldX = params.x
                val oldY = params.y
                clampPosition(params)
                if (oldX != params.x || oldY != params.y) windowManager.updateViewLayout(floatingView, params)
            }
        }

        windowManager.addView(floatingView, params)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun clampPosition(params: WindowManager.LayoutParams) {
        val size = android.graphics.Point()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getSize(size)
        params.x = params.x.coerceIn(0, (size.x - floatingView.width).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (size.y - floatingView.height - dp(24)).coerceAtLeast(0))
    }

    private fun createDirButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 25f
            setBackgroundColor(Color.TRANSPARENT)
            setTextColor(Color.WHITE)
            minimumWidth = 0
            minimumHeight = 0
            setPadding(0, 0, 0, 0)
            layoutParams = GridLayout.LayoutParams().apply { width = dp(48); height = dp(48) }
            setOnClickListener { onClick() }
        }
    }

    private fun createEmptySpace(): View {
        return View(this).apply {
            layoutParams = GridLayout.LayoutParams().apply {
                width = dp(48)
                height = dp(48)
            }
        }
    }

    private fun moveLocation(northMeters: Double, eastMeters: Double) {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val currentLat = prefs.getString(KEY_LAT, DEFAULT_LAT.toString())?.toDoubleOrNull() ?: DEFAULT_LAT
        val currentLon = prefs.getString(KEY_LONG, DEFAULT_LONG.toString())?.toDoubleOrNull() ?: DEFAULT_LONG

        val latOffset = northMeters / 111111.0
        val newLat = (currentLat + latOffset).coerceIn(-90.0, 90.0)
        val lonOffset = eastMeters / (111111.0 * cos(Math.toRadians(newLat)))
        val newLon = (currentLon + lonOffset).coerceIn(-180.0, 180.0)

        prefs.edit().apply {
            putString(KEY_LAT, "%.6f".format(Locale.US, newLat))
            putString(KEY_LONG, "%.6f".format(Locale.US, newLon))
            putBoolean(KEY_IS_ENABLED, true)
            apply()
        }
        contentResolver.notifyChange("content://$AUTHORITY".toUri(), null)
    }

    override fun onDestroy() {
        isRunning = false
        if (::floatingView.isInitialized && ::windowManager.isInitialized && floatingView.isAttachedToWindow) {
            try {
                windowManager.removeView(floatingView)
            } catch (error: IllegalArgumentException) {
                Log.w("xPoint", "Floating view was already removed", error)
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
