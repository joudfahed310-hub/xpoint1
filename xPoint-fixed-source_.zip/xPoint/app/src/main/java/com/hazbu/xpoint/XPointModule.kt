package com.hazbu.xpoint

import android.util.Log
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.ModuleLoadedParam
import io.github.libxposed.api.XposedModuleInterface.PackageReadyParam
import java.lang.reflect.Method

/** Modern API 101 entry. Legacy LSPatch uses LegacyXPointModule instead. */
class XPointModule : XposedModule() {
    private val hooks = XPointHooks(object : XPointHooks.HookBridge {
        override fun intercept(method: Method, callback: (XPointHooks.HookChain) -> Any?) {
            this@XPointModule.hook(method).intercept { chain ->
                callback(object : XPointHooks.HookChain {
                    override val thisObject: Any? get() = chain.thisObject
                    override val args: List<Any?> get() = chain.args.toList()
                    override fun proceed(): Any? = chain.proceed()
                })
            }
        }
    })

    override fun onModuleLoaded(param: ModuleLoadedParam) {
        super.onModuleLoaded(param)
        Log.i("xPoint", "Modern module loaded: ${param.processName}")
    }

    override fun onPackageReady(param: PackageReadyParam) {
        super.onPackageReady(param)
        hooks.onPackageReady(XPointHooks.PackageReadyParam(param.packageName, param.classLoader))
    }
}