package com.hazbu.xpoint

import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex

/** Public Esri raster services. Noncommercial use only under the linked provider terms. */
internal object MapSources {
    private class ArcGisSource(name: String, service: String, copyright: String) :
        OnlineTileSourceBase(name, 0, 19, 256, ".png", arrayOf(
            "https://services.arcgisonline.com/ArcGIS/rest/services/$service/MapServer/tile/"
        ), copyright) {
        override fun getTileURLString(pMapTileIndex: Long): String =
            baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" +
                MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
    }

    val imagery: OnlineTileSourceBase = ArcGisSource(
        "xPoint_Esri_Imagery", "World_Imagery",
        "Esri, Vantor, Earthstar Geographics, GIS User Community"
    )
    val roads: OnlineTileSourceBase = ArcGisSource(
        "xPoint_Esri_Roads", "Reference/World_Transportation",
        "Esri, HERE, Garmin, © OpenStreetMap contributors"
    )
    val labels: OnlineTileSourceBase = ArcGisSource(
        "xPoint_Esri_Labels", "Reference/World_Boundaries_and_Places",
        "Esri, HERE, Garmin, © OpenStreetMap contributors, GIS User Community"
    )
}