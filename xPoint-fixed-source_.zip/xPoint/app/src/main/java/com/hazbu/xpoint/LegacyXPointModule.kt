package com.hazbu.xpoint

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

/** API 82 entry for classic LSPatch and legacy Xposed loaders. */
class LegacyXPointModule : IXposedHookLoadPackage {
    override fun handleLoadPackage(param: XC_LoadPackage.LoadPackageParam) {
        // A separate engine per package keeps hooks and coordinate state isolated.
        val hooks = XPointHooks(object : XPointHooks.HookBridge {
            override fun intercept(method: Method, callback: (XPointHooks.HookChain) -> Any?) {
                XposedBridge.hookMethod(method, object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        try {
                            val result = callback(object : XPointHooks.HookChain {
                                override val thisObject: Any? get() = param.thisObject
                                override val args: List<Any?> get() = param.args.toList()
                                override fun proceed(): Any? {
                                    try {
                                        return XposedBridge.invokeOriginalMethod(
                                            method, param.thisObject, param.args
                                        )
                                    } catch (error: InvocationTargetException) {
                                        throw (error.targetException ?: error)
                                    }
                                }
                            })
                            // Skips the second invocation, even for a null/void result.
                            param.result = result
                        } catch (error: Throwable) {
                            param.throwable = error
                        }
                    }
                })
            }
        })
        XposedBridge.log("xPoint: legacy module loaded in ${param.packageName}")
        hooks.onPackageReady(XPointHooks.PackageReadyParam(param.packageName, param.classLoader))
    }
}